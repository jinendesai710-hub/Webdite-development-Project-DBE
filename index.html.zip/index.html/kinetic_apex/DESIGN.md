# Design System Strategy: The Body Project

## 1. Overview & Creative North Star

### Creative North Star: "Kinetic Precision"
This design system is not a gym template; it is a high-performance instrument. Inspired by the frontier-pushing aesthetics of aerospace engineering, "Kinetic Precision" focuses on the intersection of human peak performance and technical excellence. We utilize expansive "Dark Space" to create a sense of focus, allowing the content to breathe with the same intentionality as an elite athlete’s breath.

By breaking the traditional rigid grid through **intentional asymmetry**—such as offset typography and overlapping imagery—we mirror the dynamic movement of the human body. This system rejects the cluttered, loud tropes of fitness branding in favor of an editorial, high-end atmosphere that feels both professional and exclusive.

---

## 2. Colors & Surface Philosophy

The palette is rooted in deep obsidian and charcoal, providing a high-contrast stage for the vibrant `primary` accent.

*   **Primary (`#FFB5A0` / `#FF5724`):** Our "Kinetic Energy." Use the vibrant `primary_container` for high-impact CTAs.
*   **The Background (`#111416`):** Not a flat black, but a deep, dimensional charcoal that feels premium and "infinite."

### The "No-Line" Rule
**Explicit Instruction:** Traditional 1px solid borders are prohibited for sectioning. Structural boundaries must be achieved through tonal shifts. For example, a training module should sit on `surface_container_low` against a `surface` background. If you feel the need for a line, use a background color change instead.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. 
*   **Base:** `surface` (#111416)
*   **Nesting:** Place a `surface_container` card inside a `surface_container_low` section. This creates "soft depth"—a sophisticated alternative to drop shadows.

### The "Glass & Gradient" Rule
To elevate the high-tech feel, utilize **Glassmorphism** for floating navigational elements or performance overlays.
*   **Recipe:** `surface_variant` at 60% opacity + `backdrop-blur: 20px`.
*   **Signature Textures:** Apply a subtle linear gradient from `primary` (#FFB5A0) to `primary_container` (#FF5724) on primary action buttons to give them a glowing, "powered-on" appearance.

---

## 3. Typography: Editorial Authority

The typography system uses a high-contrast scale to emphasize results and data.

*   **Display & Headlines (Space Grotesk):** This typeface brings a technical, geometric edge. Use `display-lg` (3.5rem) with tight letter-spacing for hero sections to convey "Elite Performance."
*   **Title & Body (Inter):** Chosen for its exceptional readability at small scales and its neutral, professional tone. 
*   **The Hierarchy Strategy:**
    *   **Large Headlines:** Used for aspirational, result-oriented statements.
    *   **Overline Labels (`label-sm`):** Always uppercase with `0.1rem` letter spacing. Use these for technical stats (e.g., "HEART RATE," "ELAPSED TIME").
    *   **Body Text:** Keep paragraphs concise. Use `body-md` in `on_surface_variant` to maintain a high-end, low-noise aesthetic.

---

## 4. Elevation & Depth: Tonal Layering

We move away from the "Material" look by using **Ambient Shadows** and **Tonal Stacking**.

*   **The Layering Principle:** Depth is achieved by stacking the surface-container tiers. A "Highest" container naturally feels closer to the user than a "Low" container.
*   **Ambient Shadows:** For floating elements (like a performance modal), use: `box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4)`. The shadow must feel like a soft glow of darkness, not a hard edge.
*   **The "Ghost Border" Fallback:** If a container requires a border for accessibility, use the `outline_variant` token at 15% opacity. It should be felt, not seen.
*   **Kinetic Glass:** Use `surface_bright` with semi-transparency for elements that hover over imagery, allowing the "soul" of the photography to bleed through the UI.

---

## 5. Components

### Buttons: The Performance Triggers
*   **Primary:** Gradient fill (`primary` to `primary_container`), `round-sm` (0.125rem) for a sharp, technical look. No border.
*   **Secondary:** `surface_container_highest` background with `on_surface` text.
*   **Tertiary:** Ghost style. No background, `on_surface` text, with an underline that appears only on hover.

### Progress & Data Visualization
*   **Performance Rings:** Use the `primary` accent against `surface_container_highest`. 
*   **Charts:** Use `outline` for grid lines at 10% opacity. Data lines should be `primary` with a soft outer glow.

### Cards & Lists
*   **The "No-Divider" Rule:** Vertical whitespace (`spacing-8` or `spacing-12`) is your divider. In lists, use a subtle background shift on hover (`surface_container_high`) rather than a line.
*   **Imagery-Driven Cards:** High-quality, desaturated photography should fill the card background, with a `surface_container_lowest` gradient overlay at the bottom for text legibility.

### Performance Chips
*   **Style:** `round-full`, `surface_container_high` background, `label-md` typography. Used for tagging workout types (e.g., "STRENGTH," "HYPERTROPHY").

---

## 6. Do’s and Don’ts

### Do:
*   **Do** use asymmetrical layouts. Push a headline to the far left and the body text to the center-right.
*   **Do** use "Dark Space." If a section feels crowded, double the padding using `spacing-24`.
*   **Do** use high-contrast imagery (deep blacks, bright highlights) to match the UI.

### Don’t:
*   **Don’t** use pure white (#FFFFFF) for body text. Use `on_surface_variant` (#E4BEB4) to reduce eye strain and maintain a premium tone.
*   **Don’t** use standard "Drop Shadows." Stick to Tonal Layering and Ambient Shadows.
*   **Don’t** use rounded corners larger than `md` (0.375rem) for main containers. We want a sharp, technical "machine-cut" feel, not a "bubble" aesthetic.
*   **Don't** use icons with fills. Use thin, 1.5px stroke-based icons to maintain the high-tech, minimalist vibe.